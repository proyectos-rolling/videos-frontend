const mongoose = require('mongoose');

//Creacion del schema
const TaskSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    status:{
        type: String,
        required: true
    },
    owner:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "User"
    },
    created_at:{
        type: Date,
        default: Date.now()
    }
    
})

module.exports = mongoose.model('Task',TaskSchema);