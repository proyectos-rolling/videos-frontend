const express = require('express');
const router = express.Router();
const {check} = require('express-validator');
const userController = require('./controllers/userController');
const taskController  = require('./controllers/taskController');
//Ruta queuserController crea un usuario
//ALTA
router.post('/users/',
    [
        check('name','El nombre es obligatorio!').not().isEmpty(),
        check('email','El email es obligatorio!').not().isEmpty(),
        check('email','Debe ser formato email!').isEmail(),
        check('password','Debe agregar la contraseña').notEmpty(),
        check('password','El password debe ser de un minimo de 6 caracteres').isLength({min:6})

    ],userController.createUser);
//Traer usuarios
router.get('/users/',userController.index);
//TRAER 1 USUARIO sin params, usando el query
//router.get('/user/',userController.show);
//Trear 1 usuario mas resftul
router.get('/user/:id', userController.findOne);
//Borrar un usuario con el id
router.delete('/user/:id', userController.delete);
//Update Usuario
router.put('/user/:id',userController.update)
//Borrado masivo de usuarios
router.delete('/users/', userController.deleteAll);
//---------------Rutas de tasks-----
router.post('/tasks/',taskController.create);

module.exports = router;