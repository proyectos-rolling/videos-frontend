const Task = require("../models/Task");
const User = require("../models/User");

exports.create = async (req,res) =>{
    try{
        const {name,status,owner} = req.body;
        task = new Task(req.body);
        await task.save();
        const user = await User.findById(owner);
        user.tasks.push(task);
        await user.save();
        res.json({message: "Task creada correctamente!"});

    }
    catch(error){
        res.status(400).json({message: "hubo un error"});
    }
}